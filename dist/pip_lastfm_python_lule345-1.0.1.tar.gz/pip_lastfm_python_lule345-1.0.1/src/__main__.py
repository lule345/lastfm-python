from . import lastfmPython

if __name__ = '__main__':
    lastfmPython()